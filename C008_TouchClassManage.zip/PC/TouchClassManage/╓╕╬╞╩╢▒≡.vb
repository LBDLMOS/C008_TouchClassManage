﻿Public Class 指纹识别
    Private Sub 指纹识别_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        主页.Enabled = False
        MsgBox("text return 1")
        主页.TextBox2.ReadOnly = True
        Dim ID As String = InputBox("ID")
        Me.Label2.Text = "ID:" + ID
        主页.TextBox2.Text = ID
        Me.Enabled = False
        主页.Enabled = True
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Enabled = False
        主页.Enabled = True
        Me.Close()
    End Sub
End Class